import requests

class JSONHandler:
    categories_url = "https://opentdb.com/api_category.php"
    questions_url = "https://opentdb.com/api.php"

    def get_categories(self):
        r = requests.get(self.categories_url)
        categories = r.json()['trivia_categories']
        return categories

    def get_questions(self, category, difficulty="medium", amount=10):
        url = f"{self.questions_url}?category={category}&difficulty={difficulty}&amount={amount}"
        r = requests.get(url)
        questions = r.json()['results']
        return questions



