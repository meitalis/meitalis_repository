from json_handler import JSONHandler
from stats import StatisticsHandler
import random

class GameRunner:
    def __init__(self):
        self.json_handler = JSONHandler()
        self.stats = StatisticsHandler()

    def start_game(self):
        print('Welcome to Trivia game!')
        while True:
            print("Categories:")
            categories = self.json_handler.get_categories()
            for category in categories:
                category_id = category['id']
                category_name = category['name']
                print(f"{category_id}. {category_name}")

            category_id = int(input("Choose category: "))
            difficulty_id = int(input("Choose difficulty (0-2): "))
            questions_num = int(input("Choose number of questions: "))
            questions = self.json_handler.get_questions(category_id, difficulty_id, questions_num)
            self.display_questions(questions)

            continue_game = input('Do you want to play again? (Y/N) ') == 'Y'
            if not continue_game:
                break

    def display_questions(self, questions):
        for question in questions:
            print(question['question'])

            if question['type'] == 'boolean':
                user_response = int(input("Choose 0 for False or 1 for True: "))
                if user_response == question['correct_answer']:
                    print("Correct!")
                    correct = True
                else:
                    print("Wrong answer")
                    correct = False

            else:
                answers = question['incorrect_answers']
                answers.append(question['correct_answer'])
                random.shuffle(answers)

                i = 1
                for answer in answers:
                    print(f"{i}. {answer}")
                    if answer == question['correct_answer']:
                        correct_answer_index = i
                    i += 1

                user_response = int(input("Choose answer: "))
                if user_response == correct_answer_index:
                    print("Correct!")
                    correct = True
                else:
                    print("Wrong answer. The correct answer is", question['correct_answer'])
                    correct = False
            self.stats.add_question(question, correct)

game_runner = GameRunner()
game_runner.start_game()
game_runner.stats.show_questions_by_category()


