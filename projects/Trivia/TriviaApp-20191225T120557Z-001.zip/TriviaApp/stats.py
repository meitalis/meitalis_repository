import pandas as pd
import matplotlib.pyplot as plt

class StatisticsHandler:
    def __init__(self):
        self.questions = {}

    def add_question(self, question, is_correct):
        text = question['question']
        if text in self.questions:
            if is_correct:
                self.questions[text]['correct'] += 1
            else:
                self.questions[text]['incorrect'] += 1
        else:
            self.questions[text] = {}
            self.questions[text]['category'] = question['category']
            self.questions[text]['difficulty'] = question['difficulty']

            if is_correct:
                self.questions[text]['correct'] = 1
                self.questions[text]['incorrect'] = 0
            else:
                self.questions[text]['correct'] = 0
                self.questions[text]['incorrect'] = 1

    def show_questions_by_category(self):
        df = pd.DataFrame(self.questions).T
        df = df.groupby(['category'])['correct', 'incorrect'].sum()
        df.plot.bar()
        plt.show()

    def show_questions_by_difficulty(self):
        df = pd.DataFrame(self.questions).T
        df = df.groupby(['difficulty'])['correct', 'incorrect'].sum()
        df.plot.bar()
        plt.show()

    def display_questions(self):
        print(self.questions)
